@extends('layouts.front')

@section('content')

<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <ul class="pages">
                    <li>
                        <a href="{{ route('front.index') }}">
                            {{ $langg->lang17 }}
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('user-forgot') }}">
                            {{ $langg->lang190 }}
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>


<section class="login-signup forgot-password">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="login-area">
                    <div class="header-area forgot-passwor-area">
                        <h4 class="title">You are already registered </h4>
                        <p class="text">
                            {{--  {{ $langg->lang192 }}  --}}
                            Please verify your mobile number
                          </p>
                    </div>
                    <div class="login-form">
                        @include('includes.admin.form-login')
                        <form  action="{{route('user-rotp')}}" method="GET">
                            {{ csrf_field() }}
                            <div class="form-input">
                                {{--  <input type="email" name="email" class="User Name" placeholder="{{ $langg->lang193 }}"
                                    required="">  --}}
                                    <input type="text" name="phone" class="User Name" placeholder="Mobile number"
                                    required="">

                                <i class="icofont-user-alt-5"></i>
                            </div>
                            <div class="to-login-page">
                                <a href="{{ route('user.login') }}">
                                    {{ $langg->lang194 }}
                                </a>
                            </div>
                            <input class="authdata" type="hidden" value="{{ $langg->lang195 }}">
                            <button type="submit" class="submit-btn">{{ $langg->lang196 }}</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection