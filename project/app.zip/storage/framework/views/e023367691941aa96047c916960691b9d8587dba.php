			<?php if(count($prods) > 0): ?>
					<?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-lg-4 col-md-4 col-6 remove-padding">


										
										<?php echo $__env->make('includes/product/incproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

									</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-12">
					<div class="page-center mt-5">
						<?php echo $prods->appends(['search' => request()->input('search')])->links(); ?>

					</div>
				</div>
			<?php else: ?>
				<div class="col-lg-12">
					<div class="page-center">
						 <h4 class="text-center"><?php echo e($langg->lang60); ?></h4>
					</div>
				</div>
			<?php endif; ?>


<?php if(isset($ajax_check)): ?>


<script type="text/javascript">


// Tooltip Section


    $('[data-toggle="tooltip"]').tooltip({
      });
      $('[data-toggle="tooltip"]').on('click',function(){
          $(this).tooltip('hide');
      });




      $('[rel-toggle="tooltip"]').tooltip();

      $('[rel-toggle="tooltip"]').on('click',function(){
          $(this).tooltip('hide');
      });


// Tooltip Section Ends

</script>

<?php endif; ?>