<?php $__env->startSection('content'); ?>

<!-- Breadcrumb Area Start -->
<div class="breadcrumb-area">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <!-- Breadcrumb Area End -->

			  <ul class="pages">
          <li>
            <a href="<?php echo e(route('front.index')); ?>">
              <?php echo e($langg->lang17); ?>

            </a>
          </li>
          <li>
            <a href="<?php echo e(route('front.vendorlist')); ?>">
            Brands
            </a>
          </li>
        </ul>


      </div>
    </div>
  </div>
</div>



    <div class="container">
      <div class="row " >
       <div class="col-md-12">
	   	<div class="row">
			<?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
			<div style="padding:5px; border:1px solid #ccc;margin-left:10px;margin-bottom:10px;" class="col-md-2">
						<a href="<?php echo e(route('front.vendor',$v->shop_name)); ?>" class="single-vegory" style="text-align:center">
							<div class="right">
								<img src="<?php echo e(asset('assets/images/users/'.$v->photo)); ?>" alt="" style="height:auto; width:100%;">
							</div>
							
							<div class="left">
								<h5 class="title">
									<?php echo e($v->name); ?>

								</h5>
								
							</div>
							
						</a>
			</div>
			
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	
	
     </div>
      </div>
    </div>

  <!-- faq Area End-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script>
        $(window).on('load',function() {

            setTimeout(function(){

                $('#extraData').load('<?php echo e(route('front.extraIndex')); ?>');

            }, 500);
        });

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>