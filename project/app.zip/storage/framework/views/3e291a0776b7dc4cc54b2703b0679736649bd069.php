							
                                <?php if($prod->user_id != 0): ?>

                                
                                <?php if($prod->user->is_vendor == 2): ?>

	                            <?php if(isset($_GET['max'])): ?>  

	                            <?php if($prod->vendorPrice() <= $_GET['max']): ?>

									<div class="col-lg-4 col-md-4 col-6 remove-padding">


										
										<?php echo $__env->make('includes/product/incproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									</div>

								<?php endif; ?>

								<?php else: ?> 

									<div class="col-lg-4 col-md-4 col-6 remove-padding">

										
										<?php echo $__env->make('includes/product/incproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									</div>

								<?php endif; ?>

								<?php endif; ?>

                                

								<?php else: ?> 

							<div class="col-lg-4 col-md-4 col-6 remove-padding">

										
										<?php echo $__env->make('includes/product/incproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>

								<?php endif; ?>