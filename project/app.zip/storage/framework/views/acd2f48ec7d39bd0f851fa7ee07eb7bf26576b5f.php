                                
                                <?php if($prod->user_id != 0): ?>

                                
                                <?php if($prod->user->is_vendor == 2): ?>

										
										<?php echo $__env->make('includes/product/incproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								<?php endif; ?>

                                

								<?php else: ?> 


										
										<?php echo $__env->make('includes/product/incproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								<?php endif; ?>