										<div class="col-lg-3 col-md-4 col-6 remove-padding">

											
											<?php echo $__env->make('includes/product/incproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</div>